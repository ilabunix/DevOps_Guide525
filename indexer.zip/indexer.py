
import boto3
import os
import uuid
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import BedrockEmbeddings
from langchain.vectorstores import OpenSearchVectorSearch

def handler(event, context):
    s3 = boto3.client("s3")
    bucket = os.environ["KB_BUCKET"]
    endpoint = os.environ["OPENSEARCH_ENDPOINT"]
    index_name = os.environ["OPENSEARCH_INDEX"]
    embedder = BedrockEmbeddings(model_id="amazon.titan-embed-text-v1")
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    vectorstore = OpenSearchVectorSearch(index_name=index_name, endpoint=endpoint, embedding=embedder)

    objects = s3.list_objects_v2(Bucket=bucket)
    for obj in objects.get("Contents", []):
        key = obj["Key"]
        if not key.endswith((".md", ".txt")):
            continue
        file = s3.get_object(Bucket=bucket, Key=key)
        content = file["Body"].read().decode("utf-8")
        chunks = splitter.split_text(content)
        vectorstore.add_texts(chunks, metadatas=[{"source": key}] * len(chunks))
    return {"status": "success", "files_indexed": len(objects.get("Contents", []))}
