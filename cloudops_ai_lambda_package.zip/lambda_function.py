
import json
import boto3
from langchain.document_loaders import S3FileLoader

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
bedrock = boto3.client("bedrock-runtime")

bucket = "cloudops-ai-knowledge"
table_name = "CloudOpsChatHistory"
model_id = "amazon.titan-text-express-v1"

def lambda_handler(event, context):
    query = event.get("query", "").strip()
    if not query:
        return {"response": "Please enter a valid question."}

    loader = S3FileLoader(bucket=bucket)
    docs = loader.load()
    context_docs = [doc.page_content for doc in docs if query.lower() in doc.page_content.lower()]

    if not context_docs:
        return {"response": "No matching documents found."}

    response_text = ask_bedrock(query, context_docs)
    save_to_dynamodb(query, response_text)
    return {"response": response_text}

def ask_bedrock(query, docs):
    context = "\n".join(docs)
    payload = {
        "prompt": f"Troubleshooting Query: {query}\n\nRelevant Docs:\n{context}",
        "maxTokens": 500
    }
    response = bedrock.invoke_model(modelId=model_id, body=json.dumps(payload))
    result = json.loads(response["body"].read())
    return result.get("completion", "No response.")

def save_to_dynamodb(query, response):
    table = dynamodb.Table(table_name)
    table.put_item(Item={"query": query, "response": response})
